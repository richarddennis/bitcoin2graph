/**
 * vin.
 * Created by straumat on 01/09/16.
 */
package com.oakinvest.b2g.bitcoin.dto.bitcoin.core.getrawtransaction.vin;