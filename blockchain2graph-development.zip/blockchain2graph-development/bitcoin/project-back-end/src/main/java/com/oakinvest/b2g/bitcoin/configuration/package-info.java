/**
 * Configuration.
 *
 * @author straumat
 */
package com.oakinvest.b2g.bitcoin.configuration;