/**
 * DTO.
 *
 * @author straumat
 */
package com.oakinvest.b2g.bitcoin.dto;