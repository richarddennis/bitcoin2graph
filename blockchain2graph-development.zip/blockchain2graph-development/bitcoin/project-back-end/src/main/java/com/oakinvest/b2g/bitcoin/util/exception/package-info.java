/**
 * Exceptions.
 */
package com.oakinvest.b2g.bitcoin.util.exception;