/**
 * Bitcoin core DTO.
 * Created by straumat on 26/08/16.
 */
package com.oakinvest.b2g.bitcoin.dto.bitcoin.core;