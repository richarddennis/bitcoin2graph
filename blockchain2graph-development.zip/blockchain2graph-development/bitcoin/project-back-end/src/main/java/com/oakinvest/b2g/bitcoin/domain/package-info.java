/**
 * Domain data.
 *
 * @author straumat
 */
package com.oakinvest.b2g.bitcoin.domain;