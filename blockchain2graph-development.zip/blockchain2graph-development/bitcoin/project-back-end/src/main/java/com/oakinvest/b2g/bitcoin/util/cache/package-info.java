/**
 * Cache.
 */
package com.oakinvest.b2g.bitcoin.util.cache;