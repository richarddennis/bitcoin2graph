/**
 * Spring providers.
 */
package com.oakinvest.b2g.bitcoin.util.providers;