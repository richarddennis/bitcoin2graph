/**
 * Bitcoin application package.
 */
package com.oakinvest.b2g.bitcoin;