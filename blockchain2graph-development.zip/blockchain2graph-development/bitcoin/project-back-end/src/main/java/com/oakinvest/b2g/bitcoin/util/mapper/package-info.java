/**
 * Bitcoin mapper util.
 * Created by straumat on 12/04/17.
 */
package com.oakinvest.b2g.bitcoin.util.mapper;