/**
 * getrawtransaction response.
 * Created by straumat on 31/08/16.
 */
package com.oakinvest.b2g.bitcoin.dto.bitcoin.core.getrawtransaction;