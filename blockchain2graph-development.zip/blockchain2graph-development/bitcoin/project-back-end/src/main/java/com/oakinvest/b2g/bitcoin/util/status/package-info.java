/**
 * Application status dto.
 */
package com.oakinvest.b2g.bitcoin.util.status;