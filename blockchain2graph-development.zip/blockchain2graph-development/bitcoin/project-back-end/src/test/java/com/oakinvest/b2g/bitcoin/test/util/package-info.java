/**
 * Util package for bitcoin test.
 */
package com.oakinvest.b2g.bitcoin.test.util;