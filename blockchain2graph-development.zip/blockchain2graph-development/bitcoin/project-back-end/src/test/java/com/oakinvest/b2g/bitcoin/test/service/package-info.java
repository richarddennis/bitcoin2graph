/**
 * Tests for the service layers.
 * Created by straumat on 28/08/16.
 */
package com.oakinvest.b2g.bitcoin.test.service;