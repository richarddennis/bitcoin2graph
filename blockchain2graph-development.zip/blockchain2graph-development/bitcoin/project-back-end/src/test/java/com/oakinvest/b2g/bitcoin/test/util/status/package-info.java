/**
 * Status util.
 */
package com.oakinvest.b2g.bitcoin.test.util.status;