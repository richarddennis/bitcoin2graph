/**
 * batch test.
 * Created by straumat on 18/03/17.
 */
package com.oakinvest.b2g.bitcoin.test.batch;